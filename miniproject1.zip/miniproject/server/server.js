const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const dataRoutes = require('./routes/dataRoutes');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve frontend from public folder
app.use(express.static('public'));

// API routes
app.use('/data', dataRoutes);

// ✅ Connect to MongoDB Atlas (replace <password> with real one)
const mongoURI = 'mongodb+srv://mini:25a19b00@cluster0.xdjqf.mongodb.net/miniProjectDB?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(mongoURI)
  .then(() => console.log('✅ Connected to MongoDB Atlas'))
  .catch((err) => console.error('❌ MongoDB connection error:', err));

// Start server
app.listen(5000, () => console.log('Server running on http://localhost:5000'));
