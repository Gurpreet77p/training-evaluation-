const express = require('express');
const router = express.Router();
const Data = require('../models/data.js');

// Create
router.post('/', async (req, res) => {
  const newData = new Data(req.body);
  const saved = await newData.save();
  res.json(saved);
});

// Read
router.get('/', async (req, res) => {
  const data = await Data.find();
  res.json(data);
});

// Update
router.put('/:id', async (req, res) => {
  const updated = await Data.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// Delete
router.delete('/:id', async (req, res) => {
  await Data.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted successfully' });
});

module.exports = router;
