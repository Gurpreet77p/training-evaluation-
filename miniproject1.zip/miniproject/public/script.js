const apiURL = 'http://localhost:5000/data';

async function addData() {
  const name = document.getElementById('name').value;
  const info = document.getElementById('info').value;

  await fetch(apiURL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, info })
  });

  getData(); // Refresh after adding
}

async function getData() {
  const res = await fetch(apiURL);
  const data = await res.json();

  const list = document.getElementById('dataList');
  list.innerHTML = '';

  data.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${item.name}: ${item.info}
      <button onclick="deleteData('${item._id}')">Delete</button>
      <button onclick="startEdit('${item._id}', '${item.name}', '${item.info}')">Edit</button>
    `;
    list.appendChild(li);
  });
}

async function deleteData(id) {
  await fetch(`${apiURL}/${id}`, { method: 'DELETE' });
  getData();
}


function startEdit(id, name, info) {
  document.getElementById('name').value = name;
  document.getElementById('info').value = info;

  const addBtn = document.querySelector('button[onclick="addData()"]');
  addBtn.textContent = 'Update Data';
  addBtn.onclick = () => updateData(id);
}

async function updateData(id) {
  const name = document.getElementById('name').value;
  const info = document.getElementById('info').value;

  await fetch(`${apiURL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, info })
  });

  // Reset form and button
  document.getElementById('name').value = '';
  document.getElementById('info').value = '';
  const addBtn = document.querySelector('button[onclick]');
  addBtn.textContent = 'Add Data';
  addBtn.onclick = addData;

  getData(); // Refresh
}

